from gatilhoreneg import *

df_access = GatilhoReneg.conexaoAccessImportacao()
df_painel = GatilhoReneg.raspaPainelServico()
validador, resumoAnalise = GatilhoReneg.validacaoImportacao(df_access, df_painel)