from datetime import datetime
import pyodbc
import pandas as pd
import win32com.client


class GatilhoReneg:

    def __init__(self):
        self.teste = 'teste'

    @staticmethod
    def conexaoAccessImportacao(caminhoBd, dataConsulta):

        '''

        :param caminhoBd: Caminho em que se encontra o Access da Importação da Indra
        :param dataConsulta: Data a partir da qual se deseja obter as informações
        :return: Retorna um Data Frame com as informações da Importação
        '''



        try:
            datetime.datetime.strptime(dataConsulta, '%-m/%-d/%Y')

            try:
                dateConsulta = datetime.strptime(dataConsulta,'%-m/%-d/%Y')
                conn = pyodbc.connect(
                    r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ='+caminhoBd+';')
                #cursor = conn.cursor()
                ssql = ''
                informacoesAccess = pd.read_sql(ssql,conn)

                '''
                Inserir aqui código para salvar alguma informação no Log de que a informação foi consultada com sucesso
                '''

                return informacoesAccess




            except Exception as ex:

                '''
                Inserir aqui código para salvar alguma informação no Log de que houve erro ao consultar a informação
                '''

                print(ex)
                # raise ValueError("Não foi possível conectar ao Access, verificar se o mesmo não está em uso ou corrompido!")
        except ValueError:

            '''
            Inserir aqui código para salvar alguma informação no Log de que houve erro de formato de data
            '''
            raise ValueError("Formato de Data Incorreto! Formato requerido: MM/DD/AAAA")


    @staticmethod
    def raspaPainelServico(dataRaspagem):

        '''

        :param dataRaspagem: Data em que se deseja raspar as informações do Painel de Serviço
        :return dfRaspagem: retorna um Data Frame com a informação raspada no Painel de Serviço
        '''

        try:
            datetime.datetime.strptime(dataRaspagem, '%d/%m/%Y')
            try:
                dfRaspagem = pd.DataFrame()
                '''
                Aqui entra o código de raspagem de tela
                e transformação em um Dataframe
                '''

                '''
                Inserir código para guardar o Dataframe raspado em uma tabela no Sqlite
                '''

                '''
                Inserir aqui código para salvar alguma informação no Log de que houve erro ao consultar a informação
                '''
                return dfRaspagem
            except Exception as ex:
                print(ex)
        except ValueError:
            raise ValueError("Formato de Data Incorreto! Formato requerido: DD/MM/AAAA")

    @staticmethod
    def validacaoImportacao(dataFrameAccess, dataFrameRaspagem):

        '''

        :param dataFrameAccess: Data frame proveniente do Access de Importação
        :param dataFrameRaspagem: Data frame proveniente da Raspagem de Tela
        :return validador: Retorna a validação como boolean, True ou False
        :return resumoDataFrame: Retorna um Data frame com as informações resumidas
        '''

        validador = False
        resumoDataFrame = pd.DataFrame()
        analiticoDataFrame = pd.DataFrame()

        '''
        Aqui vai estar o código para validar as informações dos dois Data Frames, 
        '''

        analiticoDataFrame.to_excel('RelatorioAnalitico.xlsx')

        return validador, resumoDataFrame

    @staticmethod
    def gerarEmail(validador, resumoDataFrame):


        try:
            if validador == False:
                table = resumoDataFrame
                body = '<html><body>Prezados,<br><br>Houve divergência entra a raspagem do Robô e do Gatilho. Favor verificar.<br><br>' + table.to_html() + '<br><br>Att,<br>G@t1lh0_</body></html>'

                olMailItem = 0x0
                obj = win32com.client.Dispatch("Outlook.Application")
                newMail = obj.CreateItem(olMailItem)
                newMail.Subject = "Gatilho Analytics SOAS - Divergência na Importação da Operação de Renegociação"
                newMail.SentOnBehalfOfName = "IndicadoresOperacoesCentralizadas@correio.itau.com.br"
                newMail.To = "vinicius-campos.fanti@itau-unibanco.com.br"
                anexoAnalitico = 'RelatorioAnalitico.xlsx'
                newMail.HTMLBody = body
                newMail.Attachments.Add(Source=anexoAnalitico)
                newMail.display(True)

        except Exception as ex:
            print(ex)